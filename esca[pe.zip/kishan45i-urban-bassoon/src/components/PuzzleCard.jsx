import React from 'react';
import './PuzzleCard.css';

export function PuzzleCard({
  puzzle,
  onSelectAnswer,
  onSubmitAnswer,
  selectedAnswer,
  answered,
  showFeedback,
  lastPoints
}) {
  if (!puzzle) return null;

  return (
    <div className="puzzle-card">
      <div className="puzzle-question">{puzzle.question}</div>

      <div className="puzzle-options">
        {puzzle.options.map((option, index) => (
          <button
            key={index}
            className={`puzzle-option ${
              selectedAnswer === index ? 'selected' : ''
            } ${
              answered && index === puzzle.correct ? 'correct' : ''
            } ${
              answered && index === selectedAnswer && index !== puzzle.correct ? 'wrong' : ''
            }`}
            onClick={() => onSelectAnswer(index)}
            disabled={answered}
          >
            {option}
          </button>
        ))}
      </div>

      {selectedAnswer !== null && !answered && (
        <button className="btn btn-large" onClick={onSubmitAnswer}>
          SUBMIT ANSWER
        </button>
      )}

      {showFeedback && (
        <div className={`feedback ${answered && selectedAnswer === puzzle.correct ? 'correct-feedback' : 'wrong-feedback'}`}>
          <div className="feedback-icon">
            {answered && selectedAnswer === puzzle.correct ? '✓' : '✗'}
          </div>
          <div className="feedback-text">
            {answered && selectedAnswer === puzzle.correct ? 'CORRECT!' : 'WRONG!'}
          </div>
          {lastPoints > 0 && (
            <div className="points-popup">+{lastPoints}</div>
          )}
          <div className="explanation">{puzzle.explanation}</div>
        </div>
      )}
    </div>
  );
}
