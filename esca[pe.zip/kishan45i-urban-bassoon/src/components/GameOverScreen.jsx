import React from 'react';
import './GameOverScreen.css';

export function GameOverScreen({ stats, onPlayAgain, onMainMenu }) {
  return (
    <div className="game-over-screen">
      <div className="game-over-content">
        <h1 className="game-over-title">GAME OVER</h1>
        <p className="game-over-subtitle">The system locked you in.</p>

        <div className="stats-display">
          <div className="stat-item">
            <span className="stat-label">FINAL SCORE</span>
            <span className="stat-value">{stats.score}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">LEVEL REACHED</span>
            <span className="stat-value">{stats.level}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">BEST COMBO</span>
            <span className="stat-value">{stats.bestCombo}x</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">ACCURACY</span>
            <span className="stat-value">
              {stats.questionsAnswered > 0 
                ? Math.round((stats.correctAnswers / stats.questionsAnswered) * 100) 
                : 0}%
            </span>
          </div>
        </div>

        <div className="game-over-buttons">
          <button className="btn btn-large" onClick={onPlayAgain}>
            TRY AGAIN
          </button>
          <button className="btn btn-large btn-secondary" onClick={onMainMenu}>
            MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
}
