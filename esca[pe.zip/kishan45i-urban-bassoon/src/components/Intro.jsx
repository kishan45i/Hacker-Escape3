import React, { useState, useEffect } from 'react';
import { audioManager } from '../lib/audio';
import './Intro.css';

export function Intro({ onIntroComplete }) {
  const [screen, setScreen] = useState(0); // 0: loading, 1: access denied, 2: protocol, 3: countdown, 4: go
  const [loadingPercent, setLoadingPercent] = useState(0);
  const [countdownNum, setCountdownNum] = useState(null);
  const [canSkip, setCanSkip] = useState(false);

  useEffect(() => {
    audioManager.init();
  }, []);

  // Screen 0: Loading bar
  useEffect(() => {
    if (screen === 0) {
      let percent = 0;
      const interval = setInterval(() => {
        percent += Math.random() * 25;
        if (percent >= 82) {
          percent = 82;
          clearInterval(interval);
          audioManager.loadingBeep();
          setTimeout(() => setScreen(1), 500);
        } else {
          audioManager.loadingBeep();
        }
        setLoadingPercent(Math.floor(percent));
      }, 150);

      return () => clearInterval(interval);
    }
  }, [screen]);

  // Screen 1: Access Denied
  useEffect(() => {
    if (screen === 1) {
      audioManager.errorBeep();
      setTimeout(() => {
        setScreen(2);
      }, 1000);
    }
  }, [screen]);

  // Screen 2: Security Protocol
  useEffect(() => {
    if (screen === 2) {
      audioManager.tickBeep();
      setTimeout(() => {
        setScreen(3);
      }, 1000);
    }
  }, [screen]);

  // Screen 3: Countdown
  useEffect(() => {
    if (screen === 3) {
      setCanSkip(true);
      let count = 3;
      setCountdownNum(count);
      audioManager.tickBeep();

      const interval = setInterval(() => {
        count--;
        if (count <= 0) {
          clearInterval(interval);
          setCountdownNum(null);
          audioManager.goSound();
          setTimeout(() => {
            setScreen(4);
          }, 300);
        } else {
          audioManager.tickBeep();
          setCountdownNum(count);
        }
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [screen]);

  // Screen 4: GO! and complete
  useEffect(() => {
    if (screen === 4) {
      setTimeout(() => {
        onIntroComplete();
      }, 800);
    }
  }, [screen, onIntroComplete]);

  // Handle skip
  useEffect(() => {
    if (!canSkip) return;

    const handleKeyPress = (e) => {
      if (e.code === 'Space') {
        e.preventDefault();
        audioManager.goSound();
        setScreen(4);
        setCanSkip(false);
      }
    };

    const handleClick = () => {
      audioManager.goSound();
      setScreen(4);
      setCanSkip(false);
    };

    window.addEventListener('keydown', handleKeyPress);
    window.addEventListener('click', handleClick);

    return () => {
      window.removeEventListener('keydown', handleKeyPress);
      window.removeEventListener('click', handleClick);
    };
  }, [canSkip]);

  return (
    <div className="intro-container">
      {/* Screen 0: Loading */}
      {screen === 0 && (
        <div className="intro-screen loading-screen">
          <div className="glowing-text">INITIALIZING AI SECURITY SYSTEM...</div>
          <div className="loading-bar-container">
            <div className="loading-bar" style={{ width: `${loadingPercent}%` }} />
          </div>
          <div className="loading-percent">{loadingPercent}%</div>
        </div>
      )}

      {/* Screen 1: Access Denied */}
      {screen === 1 && (
        <div className="intro-screen access-denied-screen">
          <div className="glitch-text">ACCESS DENIED</div>
        </div>
      )}

      {/* Screen 2: Security Protocol */}
      {screen === 2 && (
        <div className="intro-screen security-protocol-screen">
          <div className="pulsing-text">SECURITY PROTOCOL ACTIVATED</div>
          <div className="scanlines"></div>
        </div>
      )}

      {/* Screen 3: Countdown / GO */}
      {screen === 3 && (
        <div className="intro-screen countdown-screen">
          <div className="time-remaining">60 SECONDS REMAINING</div>
          {countdownNum !== null ? (
            <div className="countdown-number">{countdownNum}</div>
          ) : null}
          {canSkip && countdownNum === null && (
            <div className="skip-text">PRESS SPACE TO SKIP</div>
          )}
        </div>
      )}

      {/* Screen 4: GO! */}
      {screen === 4 && (
        <div className="intro-screen go-screen">
          <div className="go-text">GO!</div>
        </div>
      )}
    </div>
  );
}
