import React, { useState, useEffect } from 'react';
import { GAME_CONFIG } from '../lib/gameLogic';
import { audioManager } from '../lib/audio';
import { getBossPuzzles } from '../lib/bossPuzzles';
import './BossFight.css';

export function BossFight({ onBossComplete, onAnswerSubmit, timeRemaining, muted }) {
  const [bossPuzzles] = useState(getBossPuzzles());
  const [currentPuzzleIndex, setCurrentPuzzleIndex] = useState(0);
  const [bossHealth, setBossHealth] = useState(3);
  const [bossPower, setBossPower] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [answered, setAnswered] = useState(false);
  const [showIntro, setShowIntro] = useState(true);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [wrongAnswers, setWrongAnswers] = useState(0);
  const [totalDamage, setTotalDamage] = useState(0);
  const [shakeScreen, setShakeScreen] = useState(false);
  const [bossShake, setBossShake] = useState(false);
  const [damageFlash, setDamageFlash] = useState(false);

  audioManager.setMuted(muted);

  // Show intro
  useEffect(() => {
    if (showIntro) {
      const timer = setTimeout(() => setShowIntro(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [showIntro]);

  const currentPuzzle = bossPuzzles[currentPuzzleIndex];
  const isGameOver = bossHealth <= 0 || bossPower >= 100 || timeRemaining <= 0;
  const isBossDefeated = correctAnswers >= 3;

  const handleAnswerSelect = (optionIndex) => {
    if (answered || showIntro || isGameOver) return;
    setSelectedAnswer(optionIndex);
  };

  const handleSubmitAnswer = () => {
    if (answered || !showIntro === false) return;

    const isCorrect = selectedAnswer === currentPuzzle.correct;
    setAnswered(true);

    if (isCorrect) {
      // Correct answer
      audioManager.successBeep();
      setCorrectAnswers(prev => prev + 1);
      setBossHealth(prev => Math.max(0, prev - 1));
      
      // Trigger boss damage effects
      setBossShake(true);
      setDamageFlash(true);
      setTimeout(() => {
        setBossShake(false);
        setDamageFlash(false);
      }, 500);

      // Submit answer with score info
      onAnswerSubmit({
        isCorrect: true,
        selectedIndex: selectedAnswer,
        correctIndex: currentPuzzle.correct,
        isBossFight: true
      });

      // Move to next puzzle
      setTimeout(() => {
        if (correctAnswers + 1 >= 3) {
          // Boss defeated
          audioManager.levelUpFanfare();
          onBossComplete({ victory: true, score: (correctAnswers + 1) * 500, wrongAnswers, totalDamage });
        } else {
          setCurrentPuzzleIndex(prev => prev + 1);
          setSelectedAnswer(null);
          setAnswered(false);
        }
      }, 1500);
    } else {
      // Wrong answer
      audioManager.wrongBuzz();
      setWrongAnswers(prev => prev + 1);
      const powerIncrease = Math.floor(100 / 3); // 33% per wrong answer
      const newPower = Math.min(100, bossPower + powerIncrease);
      setBossPower(newPower);
      setTotalDamage(prev => prev + 1);

      // Screen shake effect
      setShakeScreen(true);
      setTimeout(() => setShakeScreen(false), 400);

      // Submit wrong answer
      onAnswerSubmit({
        isCorrect: false,
        selectedIndex: selectedAnswer,
        correctIndex: currentPuzzle.correct,
        isBossFight: true
      });

      // Check if boss power maxed out
      setTimeout(() => {
        if (newPower >= 100) {
          // Boss wins
          audioManager.errorBeep();
          onBossComplete({ victory: false, reason: 'BOSS_POWER_MAXED', score: correctAnswers * 500, wrongAnswers, totalDamage });
        } else {
          // Continue with next puzzle
          setCurrentPuzzleIndex(prev => prev + 1);
          setSelectedAnswer(null);
          setAnswered(false);
        }
      }, 1500);
    }
  };

  if (showIntro) {
    return (
      <div className="boss-intro-container">
        <div className="boss-intro-robot">🤖</div>
        <div className="boss-intro-text">AI CORE ACTIVATED</div>
        <div className="boss-intro-subtitle">YOU HAVE ONE FINAL CHALLENGE</div>
      </div>
    );
  }

  if (isGameOver) {
    return (
      <div className="boss-screen">
        {isBossDefeated ? (
          <div className="boss-victory">
            <div className="victory-text">ESCAPE SUCCESSFUL!</div>
            <div className="boss-defeated-text">YOU DEFEATED THE AI CORE</div>
            <div className="system-shutdown">SYSTEM SHUTDOWN</div>
          </div>
        ) : (
          <div className="boss-defeat">
            <div className="defeat-text">SYSTEM LOCKED</div>
            <div className="escape-text">AI CORE ESCAPED</div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={`boss-fight-container ${shakeScreen ? 'shake' : ''}`}>
      {/* Boss Health Bar */}
      <div className="boss-health-section">
        <div className="boss-health-label">AI CORE HEALTH</div>
        <div className="boss-health-bar-container">
          <div 
            className={`boss-health-bar ${damageFlash ? 'damage-flash' : ''}`}
            style={{ width: `${(bossHealth / 3) * 100}%` }}
          />
        </div>
        <div className="boss-health-text">{bossHealth} / 3</div>
      </div>

      {/* Boss */}
      <div className={`boss-avatar ${bossShake ? 'shake' : ''}`}>
        🤖
      </div>

      {/* Boss Power Indicator */}
      <div className="boss-power-section">
        <div className="boss-power-label">BOSS POWER</div>
        <div className="boss-power-bar-container">
          <div 
            className="boss-power-bar"
            style={{ 
              width: `${bossPower}%`,
              backgroundColor: bossPower > 70 ? '#ff3333' : bossPower > 40 ? '#ffaa00' : '#00ff88'
            }}
          />
        </div>
        <div className="boss-power-text">{bossPower}%</div>
      </div>

      {/* Puzzle */}
      <div className="boss-puzzle-container">
        <div className="boss-puzzle-title">Question {currentPuzzleIndex + 1} of 3</div>
        <div className="boss-puzzle-question">{currentPuzzle.question}</div>

        <div className="boss-options">
          {currentPuzzle.options.map((option, index) => (
            <button
              key={index}
              className={`boss-option-button ${
                selectedAnswer === index ? 'selected' : ''
              } ${
                answered && index === currentPuzzle.correct ? 'correct' : ''
              } ${
                answered && index === selectedAnswer && index !== currentPuzzle.correct ? 'wrong' : ''
              }`}
              onClick={() => handleAnswerSelect(index)}
              disabled={answered}
            >
              {option}
            </button>
          ))}
        </div>

        {!answered && selectedAnswer !== null && (
          <button className="boss-submit-button" onClick={handleSubmitAnswer}>
            SUBMIT ANSWER
          </button>
        )}

        {answered && (
          <div className={`answer-feedback ${selectedAnswer === currentPuzzle.correct ? 'correct-feedback' : 'wrong-feedback'}`}>
            {selectedAnswer === currentPuzzle.correct ? '✓ CORRECT!' : '✗ WRONG!'}
            <div className="explanation">{currentPuzzle.explanation}</div>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="boss-stats">
        <div className="stat-item">Correct: {correctAnswers}</div>
        <div className="stat-item">Wrong: {wrongAnswers}</div>
        <div className="stat-item">Time: {Math.floor(timeRemaining / 1000)}s</div>
      </div>
    </div>
  );
}
