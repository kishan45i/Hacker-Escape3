import React from 'react';
import './HowToPlayScreen.css';

export function HowToPlayScreen({ onBack }) {
  return (
    <div className="how-to-play-screen">
      <div className="how-to-play-content">
        <h1>HOW TO PLAY</h1>

        <div className="rules-section">
          <h2>Objective</h2>
          <p>Escape the AI core by answering puzzle questions before time runs out. Get the highest score!</p>
        </div>

        <div className="rules-section">
          <h2>Gameplay</h2>
          <ul className="rules-list">
            <li>60 seconds to answer as many puzzles as possible</li>
            <li>Each correct answer gives +100 points (base)</li>
            <li>Wrong answers cost 1 life and 5 seconds</li>
            <li>You start with 3 lives - lose them all and it's game over</li>
            <li>Reach Level 4+ to face the AI Boss Challenge</li>
          </ul>
        </div>

        <div className="rules-section">
          <h2>Scoring</h2>
          <ul className="rules-list">
            <li><strong>Speed Bonus:</strong> Answer in &lt;3 seconds = +50 bonus, &lt;5 seconds = +25 bonus</li>
            <li><strong>Combo Multipliers:</strong> Chain correct answers for multipliers (2x=1.2, 3x=1.5, 5x=2.0)</li>
            <li><strong>Level Bonus:</strong> +10 points per level</li>
            <li><strong>PERFECT!</strong> Answer fast AND correctly for animated celebration</li>
          </ul>
        </div>

        <div className="rules-section">
          <h2>Puzzle Types</h2>
          <ul className="rules-list">
            <li><strong>Pattern Puzzles:</strong> Find the sequence</li>
            <li><strong>Memory Puzzles:</strong> Remember what you saw</li>
            <li><strong>Logic Puzzles:</strong> Use deduction</li>
            <li><strong>Odd One Out:</strong> Find the different item</li>
            <li><strong>Code Logic:</strong> Understand code snippets (fictional)</li>
            <li><strong>Reaction Challenges:</strong> Answer fast!</li>
          </ul>
        </div>

        <div className="rules-section">
          <h2>Tips</h2>
          <ul className="rules-list">
            <li>Read questions carefully</li>
            <li>Go fast but don't rush - wrong answers cost time!</li>
            <li>Build combos for massive multipliers</li>
            <li>Watch the timer - it pulses red when time is low</li>
            <li>Reach the boss fight for the ultimate challenge</li>
          </ul>
        </div>

        <button className="btn btn-large" onClick={onBack}>
          BACK TO MENU
        </button>
      </div>
    </div>
  );
}
