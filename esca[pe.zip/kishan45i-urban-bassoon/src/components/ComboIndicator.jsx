import React from 'react';
import './ComboIndicator.css';

export function ComboIndicator({ combo, multiplier }) {
  return (
    <div className="combo-indicator">
      <div className="combo-text">COMBO x{combo}</div>
      <div className="combo-multiplier">×{multiplier.toFixed(1)}</div>
    </div>
  );
}
