import React, { useState, useEffect } from 'react';
import { BossFight } from './BossFight';
import { GameHUD } from './GameHUD';
import { PuzzleCard } from './PuzzleCard';
import { ComboIndicator } from './ComboIndicator';
import { PerfectIndicator } from './PerfectIndicator';
import { LevelUpAnimation } from './LevelUpAnimation';
import { GameLogic, GAME_CONFIG } from '../lib/gameLogic';
import { getRandomPuzzle } from '../lib/puzzles';
import { audioManager } from '../lib/audio';
import './GameScreen.css';

export function GameScreen({ onGameOver, onVictory, muted }) {
  const [gameLogic] = useState(() => new GameLogic());
  const [gameState, setGameState] = useState('playing'); // playing, isBossFight, gameOver
  const [currentPuzzle, setCurrentPuzzle] = useState(null);
  const [timeRemaining, setTimeRemaining] = useState(GAME_CONFIG.INITIAL_TIME * 1000);
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [lives, setLives] = useState(GAME_CONFIG.INITIAL_LIVES);
  const [combo, setCombo] = useState(0);
  const [showCombo, setShowCombo] = useState(false);
  const [showPerfect, setShowPerfect] = useState(false);
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [answered, setAnswered] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [lastPoints, setLastPoints] = useState(0);
  const [bossTriggered, setBossTriggered] = useState(false);

  audioManager.setMuted(muted);

  // Initialize first puzzle
  useEffect(() => {
    const difficulty = gameLogic.getDifficulty();
    const puzzle = getRandomPuzzle(difficulty);
    setCurrentPuzzle(puzzle);
    gameLogic.startPuzzle();
  }, [gameLogic]);

  // Timer countdown
  useEffect(() => {
    const interval = setInterval(() => {
      setTimeRemaining(prev => {
        const newTime = prev - 100;
        if (newTime <= 0) {
          clearInterval(interval);
          return 0;
        }
        // Pulse when time is low
        if (newTime < 10000 && newTime % 1000 < 100) {
          audioManager.tickBeep();
        }
        return newTime;
      });
    }, 100);

    return () => clearInterval(interval);
  }, []);

  // Check game over conditions
  useEffect(() => {
    if (timeRemaining <= 0 || lives <= 0) {
      setGameState('gameOver');
      onGameOver({
        score,
        level,
        lives,
        bestCombo: combo,
        questionsAnswered: gameLogic.questionsAnswered,
        correctAnswers: gameLogic.correctAnswers
      });
    } else if (gameLogic.level >= 4 && gameLogic.correctAnswers >= 3 && !bossTriggered) {
      setBossTriggered(true);
      setGameState('isBossFight');
    }
  }, [timeRemaining, lives, score, level, combo, gameLogic, onGameOver, bossTriggered]);

  const handleAnswerSelect = (optionIndex) => {
    if (answered) return;
    setSelectedAnswer(optionIndex);
  };

  const handleSubmitAnswer = () => {
    if (answered || selectedAnswer === null || !currentPuzzle) return;
    setAnswered(true);

    const isCorrect = selectedAnswer === currentPuzzle.correct;
    const timeSpent = GAME_CONFIG.INITIAL_TIME * 1000 - timeRemaining;

    if (isCorrect) {
      audioManager.correctChime();
      const result = gameLogic.calculateScore(true, timeSpent);
      
      // Check for perfect (answered in < 3 seconds)
      if (timeSpent < GAME_CONFIG.SPEED_BONUS_THRESHOLD_PERFECT) {
        setShowPerfect(true);
        setTimeout(() => setShowPerfect(false), 2000);
      }

      // Update UI
      setScore(gameLogic.score);
      setLevel(gameLogic.level);
      setCombo(gameLogic.combo);
      setLastPoints(result.points);

      // Show combo when it increases
      if (gameLogic.combo > 1) {
        setShowCombo(true);
        setTimeout(() => setShowCombo(false), 1500);
      }

      // Check for level up
      if (gameLogic.correctAnswers % 3 === 0 && gameLogic.correctAnswers > 0) {
        setShowLevelUp(true);
        audioManager.levelUpFanfare();
        setTimeout(() => setShowLevelUp(false), 2000);
      }

      // Show feedback
      setShowFeedback(true);
      setTimeout(() => {
        // Load next puzzle
        const nextDifficulty = gameLogic.getDifficulty();
        const nextPuzzle = getRandomPuzzle(nextDifficulty);
        setCurrentPuzzle(nextPuzzle);
        setSelectedAnswer(null);
        setAnswered(false);
        setShowFeedback(false);
        gameLogic.startPuzzle();
      }, 1500);
    } else {
      audioManager.wrongBuzz();
      gameLogic.calculateScore(false, timeSpent);

      // Screen shake
      document.querySelector('.game-screen')?.classList.add('shake');
      setTimeout(() => {
        document.querySelector('.game-screen')?.classList.remove('shake');
      }, 300);

      // Update lives
      setLives(gameLogic.lives);
      setCombo(0);

      // Show feedback
      setShowFeedback(true);
      setTimeout(() => {
        if (gameLogic.lives > 0) {
          // Load next puzzle
          const nextDifficulty = gameLogic.getDifficulty();
          const nextPuzzle = getRandomPuzzle(nextDifficulty);
          setCurrentPuzzle(nextPuzzle);
          setSelectedAnswer(null);
          setAnswered(false);
          setShowFeedback(false);
          gameLogic.startPuzzle();
        }
      }, 1500);
    }
  };

  const handleBossComplete = (result) => {
    if (result.victory) {
      onVictory({
        score: score + result.score,
        level: gameLogic.level,
        lives: gameLogic.lives,
        bestCombo: combo,
        questionsAnswered: gameLogic.questionsAnswered,
        correctAnswers: gameLogic.correctAnswers
      });
    } else {
      onGameOver({
        score,
        level: gameLogic.level,
        lives: gameLogic.lives,
        bestCombo: combo,
        questionsAnswered: gameLogic.questionsAnswered,
        correctAnswers: gameLogic.correctAnswers
      });
    }
  };

  if (gameState === 'isBossFight') {
    return (
      <BossFight
        onBossComplete={handleBossComplete}
        onAnswerSubmit={() => {}}
        timeRemaining={timeRemaining}
        muted={muted}
      />
    );
  }

  if (gameState === 'gameOver') {
    return null;
  }

  return (
    <div className="game-screen">
      <GameHUD score={score} level={level} lives={lives} timeRemaining={timeRemaining} />

      {showLevelUp && <LevelUpAnimation level={level} />}
      {showCombo && <ComboIndicator combo={combo} multiplier={gameLogic.getComboMultiplier()} />}
      {showPerfect && <PerfectIndicator />}

      {currentPuzzle && (
        <PuzzleCard
          puzzle={currentPuzzle}
          onSelectAnswer={handleAnswerSelect}
          onSubmitAnswer={handleSubmitAnswer}
          selectedAnswer={selectedAnswer}
          answered={answered}
          showFeedback={showFeedback}
          lastPoints={showFeedback ? lastPoints : 0}
        />
      )}
    </div>
  );
}
