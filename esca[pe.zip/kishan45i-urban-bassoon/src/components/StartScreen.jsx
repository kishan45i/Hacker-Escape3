import React, { useState, useEffect, useRef } from 'react';
import { storage } from '../lib/storage';
import { audioManager } from '../lib/audio';
import './StartScreen.css';

const INITIAL_LOGS = [
  { time: '02:41:09', type: 'info', text: 'INITIATING ICEBREAKER PROTOCOL V4.2...' },
  { time: '02:41:10', type: 'success', text: 'BYPASSING NEURAL GATEWAY NODE 7... SUCCESS' },
  { time: '02:41:11', type: 'error', text: 'WARNING: TRACE DETECTED (COUNTERMEASURE DEPLOYED: GHOST DAEMON HOOKED)' },
  { time: '02:41:12', type: 'cyan', text: 'ENCRYPTION CIPHER: SHA-512 MATRIX ACTIVE // COMPUTE SHARDS 64/64' },
  { time: '02:41:14', type: 'dim', text: 'SYNCHRONIZING EXPLOIT PAYLOAD BUFFERS OVER PORT 8080... OK' },
  { time: '02:41:16', type: 'info', text: 'TYPE "start" OR CLICK "INITIALIZE BREACH" TO COMMENCE INFILTRATION' }
];

export function StartScreen({ onStartGame, onHowToPlay, onLeaderboard }) {
  const [stats, setStats] = useState({
    gamesPlayed: 0,
    highestScore: 0,
    highestLevel: 1
  });
  const [logs, setLogs] = useState(INITIAL_LOGS);
  const [commandInput, setCommandInput] = useState('');
  const logFeedRef = useRef(null);

  useEffect(() => {
    setStats({
      gamesPlayed: storage.getGamesPlayed(),
      highestScore: storage.getHighestScore(),
      highestLevel: storage.getHighestLevel()
    });
  }, []);

  useEffect(() => {
    if (logFeedRef.current) {
      logFeedRef.current.scrollTop = logFeedRef.current.scrollHeight;
    }
  }, [logs]);

  const getTimeString = () => {
    const now = new Date();
    return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
  };

  const addLog = (type, text) => {
    setLogs(prev => [...prev, { time: getTimeString(), type, text }]);
  };

  const handleCommandSubmit = (e) => {
    e.preventDefault();
    const cmd = commandInput.trim().toLowerCase();
    if (!cmd) return;

    audioManager.beep(950, 50);
    addLog('prompt', `> ${commandInput}`);
    setCommandInput('');

    if (cmd === 'start' || cmd === 'breach' || cmd === 'run') {
      addLog('success', 'INITIALIZING NEURAL OVERRIDE... LAUNCHING MISSION!');
      audioManager.levelUpFanfare();
      setTimeout(onStartGame, 600);
    } else if (cmd === 'help') {
      addLog('cyan', 'AVAILABLE PROTOCOLS:');
      addLog('info', '  start / breach  - Launch the hacking game');
      addLog('info', '  protocols / how - View operational rules & guide');
      addLog('info', '  leaderboard     - Access top netrunner rankings');
      addLog('info', '  stats           - View lifetime telemetry metrics');
      addLog('info', '  cipher          - Run quantum decryption matrix');
      addLog('info', '  inject          - Inject remote kernel exploit payload');
      addLog('info', '  overclock       - Overclock cyberdeck CPU bus');
      addLog('info', '  clear           - Flush terminal feed');
    } else if (cmd === 'protocols' || cmd === 'how' || cmd === 'guide') {
      addLog('cyan', 'OPENING MISSION PROTOCOLS ARCHIVE...');
      setTimeout(onHowToPlay, 300);
    } else if (cmd === 'leaderboard' || cmd === 'scores') {
      addLog('cyan', 'QUERYING GLOBAL NETRUNNER REPOSITORY...');
      setTimeout(onLeaderboard, 300);
    } else if (cmd === 'stats') {
      addLog('success', `TELEMETRY DUMP: GAMES=${stats.gamesPlayed} | HIGH_SCORE=${stats.highestScore} | MAX_LEVEL=${stats.highestLevel}`);
    } else if (cmd === 'clear') {
      setLogs([]);
    } else if (cmd === 'cipher') {
      audioManager.tickBeep();
      addLog('cyan', 'QUANTUM CIPHER: COMPUTING PRIME ROOTS... SHA-512 MATRIX INVERTED [OK]');
    } else if (cmd === 'inject' || cmd === 'payload') {
      audioManager.loadingBeep();
      addLog('error', 'PAYLOAD INJECTED: MEMORY OFFSET 0x7FFF004B OVERFLOWED [EXPLOIT ARMED]');
    } else if (cmd === 'overclock') {
      audioManager.successBeep();
      addLog('success', 'CYBERDECK CPU CLOCK: 4.2 GHz -> 5.8 GHz [VOLTAGE NOMINAL]');
    } else {
      audioManager.errorBeep();
      addLog('error', `COMMAND UNRECOGNIZED: "${cmd}". TYPE "help" FOR PROTOCOL LIST.`);
    }
  };

  const handleQuickAction = (action) => {
    audioManager.beep(850, 60);
    if (action === 'cipher') {
      addLog('prompt', '> cipher_solver.exe --brute-force');
      addLog('cyan', '[CIPHER SOLVER] Parsing 256-bit AES block... Decryption key generated: 0x9B44F1');
    } else if (action === 'payload') {
      addLog('prompt', '> payload_injector.bin --target=192.168.0.240');
      addLog('error', '[PAYLOAD INJECTOR] Shellcode staged in buffer: root shell granted on daemon 8080');
    } else if (action === 'overclock') {
      addLog('prompt', '> overclock_bus --frequency=+1.6ghz');
      addLog('success', '[OVERCLOCK CPU] Cycle frequency boosted. Performance output +38%');
    }
  };

  return (
    <div className="stitch-start-deck">
      {/* 1. CENTER DASHBOARD - HACKER TERMINAL CONSOLE */}
      <section className="stitch-console-card" id="console">
        {/* Cyber Corner Brackets */}
        <span className="cyber-bracket top-left">┌</span>
        <span className="cyber-bracket top-right">┐</span>
        <span className="cyber-bracket bottom-left">└</span>
        <span className="cyber-bracket bottom-right">┘</span>

        {/* Terminal Header Bar */}
        <div className="terminal-header">
          <div className="terminal-dots-group">
            <span className="term-dot red"></span>
            <span className="term-dot yellow"></span>
            <span className="term-dot green"></span>
            <div className="term-tab">
              <span className="material-symbols-outlined term-tab-icon">terminal</span>
              <span className="term-tab-title">root@breach-daemon:~# matrix_runner.sh</span>
            </div>
          </div>

          <div className="terminal-meta-group">
            <div className="term-target-pill">
              TARGET IP: 192.168.0.240
            </div>
            <div className="term-firewall-status">
              <span className="material-symbols-outlined firewall-icon">verified_user</span>
              <span>FIREWALL 94% BYPASSED</span>
            </div>
          </div>
        </div>

        {/* Terminal Body & Stream Log Output */}
        <div className="terminal-body">
          <div className="terminal-watermark">0xDECK//SYS_BREACH</div>
          
          <div className="terminal-feed cyber-scroll" ref={logFeedRef}>
            {logs.map((log, idx) => (
              <div key={idx} className={`term-log-line ${log.type}`}>
                <span className="log-time">[{log.time}]</span>
                <span className="log-text">{log.text}</span>
              </div>
            ))}
          </div>

          {/* Interactive Monospace Prompt Input */}
          <form className="terminal-prompt-bar" onSubmit={handleCommandSubmit}>
            <span className="prompt-symbol">&gt;_</span>
            <input
              type="text"
              className="prompt-input"
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
              placeholder="ENTER COMMAND (e.g. 'start', 'protocols', 'leaderboard', 'cipher', 'help')"
              autoFocus
            />
            <span className="prompt-cursor"></span>
            <button type="submit" className="prompt-submit-btn">EXECUTE</button>
          </form>
        </div>

        {/* Terminal Bottom Actions Bar */}
        <div className="terminal-actions-bar">
          <div className="cta-buttons-cluster">
            {/* Primary Action: INITIALIZE BREACH */}
            <button 
              className="cyber-cta-btn primary"
              onClick={() => {
                audioManager.successBeep();
                onStartGame();
              }}
            >
              <span className="material-symbols-outlined btn-symbol">bolt</span>
              <span>INITIALIZE BREACH</span>
            </button>

            {/* Secondary Action: SYSTEM PROTOCOLS */}
            <button 
              className="cyber-cta-btn secondary"
              onClick={() => {
                audioManager.beep(750, 40);
                onHowToPlay();
              }}
            >
              <span className="material-symbols-outlined btn-symbol">security</span>
              <span>SYSTEM PROTOCOLS</span>
            </button>

            {/* Tertiary Action: MAINFRAME LEADERBOARD */}
            <button 
              className="cyber-cta-btn tertiary"
              onClick={() => {
                audioManager.beep(750, 40);
                onLeaderboard();
              }}
            >
              <span className="material-symbols-outlined btn-symbol">leaderboard</span>
              <span>MAINFRAME LEADERBOARD</span>
            </button>
          </div>

          {/* Quick Action Cyber Pills */}
          <div className="quick-pills-cluster">
            <span className="quick-label">QUICK:</span>
            <button 
              type="button" 
              className="quick-pill" 
              onClick={() => handleQuickAction('cipher')}
            >
              CIPHER SOLVER
            </button>
            <button 
              type="button" 
              className="quick-pill" 
              onClick={() => handleQuickAction('payload')}
            >
              PAYLOAD INJECTOR
            </button>
            <button 
              type="button" 
              className="quick-pill" 
              onClick={() => handleQuickAction('overclock')}
            >
              OVERCLOCK CPU
            </button>
          </div>
        </div>
      </section>

      {/* 2. BOTTOM TELEMETRY STAT CARDS (4-Column Bento HUD Grid) */}
      <section className="stitch-telemetry-grid">
        {/* CARD 1: GAMES COMPLETED */}
        <div className="telemetry-card">
          <span className="telemetry-tag">01_TELEMETRY</span>
          <div className="card-top">
            <div className="card-header-line">
              <span className="material-symbols-outlined card-icon primary">task_alt</span>
              <span className="card-title">GAMES COMPLETED</span>
            </div>
            <div className="card-metric primary">
              {stats.gamesPlayed} <span className="metric-denom">/ 150</span>
            </div>
          </div>
          <div className="card-bottom">
            <div className="metric-sub-row">
              <span className="sub-highlight primary">+12 THIS SESSION</span>
              <span className="sub-muted">94.6% RATIO</span>
            </div>
            <div className="progress-track">
              <div 
                className="progress-fill primary" 
                style={{ width: `${Math.min(100, Math.max(15, (stats.gamesPlayed / 50) * 100))}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* CARD 2: HIGH SCORE */}
        <div className="telemetry-card">
          <span className="telemetry-tag">02_SCORE</span>
          <div className="card-top">
            <div className="card-header-line">
              <span className="material-symbols-outlined card-icon cyan">stars</span>
              <span className="card-title">HIGH SCORE</span>
            </div>
            <div className="card-metric cyan">
              {stats.highestScore.toLocaleString()} <span className="metric-denom">PTS</span>
            </div>
          </div>
          <div className="card-bottom">
            <div className="metric-sub-row">
              <span className="sub-highlight cyan">RANK: S-TIER NETRUNNER</span>
              <span className="sub-highlight primary">TOP 0.3%</span>
            </div>
            <div className="sparkline-meter">
              <span className="spark-bar active"></span>
              <span className="spark-bar active"></span>
              <span className="spark-bar active"></span>
              <span className="spark-bar active"></span>
              <span className="spark-bar"></span>
            </div>
          </div>
        </div>

        {/* CARD 3: BEST LEVEL */}
        <div className="telemetry-card">
          <span className="telemetry-tag">03_CLEARANCE</span>
          <div className="card-top">
            <div className="card-header-line">
              <span className="material-symbols-outlined card-icon green">token</span>
              <span className="card-title">BEST LEVEL</span>
            </div>
            <div className="card-metric green">
              LVL {stats.highestLevel} <span className="metric-badge">[CYBER-CORE]</span>
            </div>
          </div>
          <div className="card-bottom">
            <div className="metric-sub-row">
              <span className="sub-highlight green">MAX OVERDRIVE UNLOCKED</span>
              <span className="sub-muted">SECTOR {stats.highestLevel}</span>
            </div>
            <div className="segmented-level-meter">
              {[...Array(8)].map((_, i) => (
                <span 
                  key={i} 
                  className={`segment-bar ${i < Math.min(8, stats.highestLevel) ? 'active' : ''}`}
                ></span>
              ))}
            </div>
          </div>
        </div>

        {/* CARD 4: SYSTEM INTEGRITY */}
        <div className="telemetry-card">
          <span className="telemetry-tag">04_HARDWARE</span>
          <div className="card-top">
            <div className="card-header-line">
              <span className="material-symbols-outlined card-icon shield">shield</span>
              <span className="card-title">SYSTEM INTEGRITY</span>
            </div>
            <div className="card-metric white">
              98.4% <span className="metric-sub-state">[OPTIMAL]</span>
            </div>
          </div>
          <div className="card-bottom">
            <div className="metric-sub-row">
              <span className="sub-highlight cyan">SHIELD ACTIVE</span>
              <span className="sub-muted">2 MIN RECHARGE</span>
            </div>
            <div className="progress-track split">
              <div className="progress-fill primary" style={{ width: '82%' }}></div>
              <div className="progress-fill alert" style={{ width: '18%' }}></div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. ACTIVE PROTOCOL STACK & NODE BYPASS MATRIX */}
      <section className="stitch-protocol-matrix">
        <div className="matrix-header">
          <div className="matrix-title">
            <span className="material-symbols-outlined matrix-icon">memory</span>
            <span>ACTIVE PROTOCOL STACK &amp; NODE BYPASS MATRIX</span>
          </div>
          <span className="matrix-sec-id">SEC_ID: 884-AX90</span>
        </div>
        <div className="matrix-grid">
          <div className="matrix-item">
            <div className="matrix-item-left">
              <span className="status-pip green"></span>
              <span className="item-name">PROXY CHAIN // ONION_v6</span>
            </div>
            <span className="item-status green">ROUTE 41 LOCKED</span>
          </div>
          <div className="matrix-item">
            <div className="matrix-item-left">
              <span className="status-pip cyan"></span>
              <span className="item-name">QUANTUM KEY CIPHER</span>
            </div>
            <span className="item-status cyan">SOLVING... (94%)</span>
          </div>
          <div className="matrix-item">
            <div className="matrix-item-left">
              <span className="status-pip red"></span>
              <span className="item-name">NEURAL ICEBREAKER</span>
            </div>
            <span className="item-status red">FIREWALL INFILTRATED</span>
          </div>
        </div>
      </section>
    </div>
  );
}
