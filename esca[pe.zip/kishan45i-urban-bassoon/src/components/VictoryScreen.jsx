import React from 'react';
import './VictoryScreen.css';

export function VictoryScreen({ stats, onPlayAgain, onMainMenu }) {
  return (
    <div className="victory-screen">
      <div className="confetti">
        {[...Array(20)].map((_, i) => (
          <div key={i} className="confetti-piece" style={{ '--delay': `${Math.random() * 0.5}s` }} />
        ))}
      </div>

      <div className="victory-content">
        <h1 className="victory-title">ESCAPE SUCCESSFUL!</h1>
        <p className="victory-subtitle">You defeated the AI core and broke free.</p>

        <div className="victory-badge">
          <span className="badge-icon">🔓</span>
          <span className="badge-text">SYSTEM SHUTDOWN</span>
        </div>

        <div className="stats-display">
          <div className="stat-item">
            <span className="stat-label">FINAL SCORE</span>
            <span className="stat-value">{stats.score}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">LEVEL REACHED</span>
            <span className="stat-value">{stats.level}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">BEST COMBO</span>
            <span className="stat-value">{stats.bestCombo}x</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">ACCURACY</span>
            <span className="stat-value">
              {stats.questionsAnswered > 0 
                ? Math.round((stats.correctAnswers / stats.questionsAnswered) * 100) 
                : 0}%
            </span>
          </div>
        </div>

        <div className="victory-buttons">
          <button className="btn btn-large" onClick={onPlayAgain}>
            PLAY AGAIN
          </button>
          <button className="btn btn-large btn-secondary" onClick={onMainMenu}>
            MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
}
