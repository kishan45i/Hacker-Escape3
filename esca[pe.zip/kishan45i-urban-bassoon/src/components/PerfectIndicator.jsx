import React from 'react';
import './PerfectIndicator.css';

export function PerfectIndicator() {
  return (
    <div className="perfect-indicator">
      <div className="perfect-text">PERFECT!</div>
      <div className="perfect-particles">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="particle" style={{ '--delay': `${i * 50}ms` }} />
        ))}
      </div>
    </div>
  );
}
