import React from 'react';
import './LevelUpAnimation.css';

export function LevelUpAnimation({ level }) {
  return (
    <div className="level-up-animation">
      <div className="level-up-text">LEVEL UP!</div>
      <div className="level-display">LEVEL {level}</div>
    </div>
  );
}
