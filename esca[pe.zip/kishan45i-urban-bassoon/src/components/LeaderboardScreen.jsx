import React, { useState, useEffect } from 'react';
import { storage } from '../lib/storage';
import './LeaderboardScreen.css';

export function LeaderboardScreen({ onBack }) {
  const [leaderboard, setLeaderboard] = useState([]);

  useEffect(() => {
    const scores = storage.getLeaderboard();
    setLeaderboard(scores);
  }, []);

  return (
    <div className="leaderboard-screen">
      <div className="leaderboard-content">
        <h1>LEADERBOARD</h1>
        <p className="leaderboard-subtitle">Top 10 Highest Scores</p>

        {leaderboard.length === 0 ? (
          <div className="no-scores">
            <p>No scores yet. Be the first to escape!</p>
          </div>
        ) : (
          <div className="leaderboard-table">
            <div className="leaderboard-header">
              <div className="rank">RANK</div>
              <div className="score">SCORE</div>
              <div className="level">LEVEL</div>
              <div className="combo">COMBO</div>
              <div className="date">DATE</div>
            </div>

            {leaderboard.map((entry, index) => (
              <div key={index} className={`leaderboard-row ${index === 0 ? 'first' : ''}`}>
                <div className="rank">#{index + 1}</div>
                <div className="score">{entry.score}</div>
                <div className="level">Level {entry.level}</div>
                <div className="combo">{entry.combo}x</div>
                <div className="date">
                  {new Date(entry.date).toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric'
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        <button className="btn btn-large" onClick={onBack}>
          BACK TO MENU
        </button>
      </div>
    </div>
  );
}
