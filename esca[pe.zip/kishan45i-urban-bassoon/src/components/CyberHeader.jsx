import React, { useState, useEffect } from 'react';
import './CyberHeader.css';
import { audioManager } from '../lib/audio';

export function CyberHeader({ gameState, onNavigate, onStartGame, muted, onToggleMute }) {
  const [uptimeSeconds, setUptimeSeconds] = useState(15509);
  const [latency, setLatency] = useState(12);

  // Live uptime counter & subtle latency flicker for authentic terminal feel
  useEffect(() => {
    const timer = setInterval(() => {
      setUptimeSeconds(prev => prev + 1);
      if (Math.random() > 0.7) {
        setLatency(Math.floor(10 + Math.random() * 6));
      }
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatUptime = (totalSec) => {
    const hrs = String(Math.floor(totalSec / 3600)).padStart(2, '0');
    const mins = String(Math.floor((totalSec % 3600) / 60)).padStart(2, '0');
    const secs = String(totalSec % 60).padStart(2, '0');
    return `${hrs}:${mins}:${secs}`;
  };

  const handleNavClick = (targetState) => {
    audioManager.beep(750, 40);
    onNavigate(targetState);
  };

  const handleAudioClick = () => {
    audioManager.beep(880, 50);
    onToggleMute();
  };

  return (
    <div className="cyber-hud-wrapper">
      {/* 1. TOP HEADER / APP BAR */}
      <header className="cyber-header">
        {/* Brand & Threat Level */}
        <div className="cyber-brand-group">
          <button 
            className="cyber-brand" 
            onClick={() => handleNavClick('start')}
            title="Return to Command Deck"
          >
            <span className="material-symbols-outlined cyber-brand-icon">terminal</span>
            <span className="cyber-brand-title">HACKER ESCAPE</span>
          </button>

          {/* Cyber Hazard Status Badge */}
          <div className="cyber-hazard-badge">
            <span className="cyber-hazard-dot"></span>
            <span className="cyber-hazard-text">THREAT LEVEL: CRITICAL [BREACH DETECTED]</span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="cyber-nav">
          <button
            className={`cyber-nav-item ${gameState === 'start' ? 'active' : ''}`}
            onClick={() => handleNavClick('start')}
          >
            CONSOLE
          </button>
          <button
            className={`cyber-nav-item ${gameState === 'howToPlay' ? 'active' : ''}`}
            onClick={() => handleNavClick('howToPlay')}
          >
            PROTOCOLS
          </button>
          <button
            className={`cyber-nav-item ${gameState === 'leaderboard' ? 'active' : ''}`}
            onClick={() => handleNavClick('leaderboard')}
          >
            MAINFRAME
          </button>
        </nav>

        {/* Trailing Controls & Live Telemetry Metrics */}
        <div className="cyber-controls-group">
          {/* Live Node Telemetry Readouts */}
          <div className="cyber-telemetry-pill">
            <span className="cyber-pill-node">NODE: <strong>0x9F_TOKYO</strong></span>
            <span className="cyber-divider">|</span>
            <span className="cyber-pill-latency">LATENCY: <strong>{latency}ms</strong></span>
            <span className="cyber-divider">|</span>
            <span className="cyber-pill-uptime">UPTIME: <strong>{formatUptime(uptimeSeconds)}</strong></span>
          </div>

          {/* Interactive Audio Toggle */}
          <button
            className={`cyber-action-btn ${muted ? 'muted' : ''}`}
            onClick={handleAudioClick}
            title={muted ? 'Unmute Audio' : 'Mute Audio'}
          >
            <span className="material-symbols-outlined cyber-btn-icon">
              {muted ? 'volume_off' : 'volume_up'}
            </span>
            <span className="cyber-audio-label">{muted ? 'AUDIO MUTED' : 'AUDIO ON'}</span>
          </button>

          {/* Header Action Button */}
          {gameState === 'playing' ? (
            <button
              className="cyber-header-cta playing"
              onClick={() => handleNavClick('start')}
              title="Abort Current Infiltration"
            >
              ABORT BREACH
            </button>
          ) : (
            <button
              className="cyber-header-cta"
              onClick={() => {
                audioManager.successBeep();
                onStartGame();
              }}
            >
              INITIALIZE BREACH
            </button>
          )}
        </div>
      </header>

      {/* 2. SUB-HUD TICKER BAR */}
      <div className="cyber-sub-hud">
        <div className="cyber-sub-hud-left">
          <span className="cyber-ticker-armed">
            <span className="cyber-ticker-beacon"></span>
            DECK STATE: ARMED
          </span>
          <span className="cyber-sub-ticker-text">SEC_04 // SUB_SYS_ACTIVE</span>
          <span className="cyber-sub-ticker-accent">CIPHER ENGINE: SHA-512 RUNNING</span>
        </div>
        <div className="cyber-sub-hud-right">
          <span>MEM ALLOC: <strong>4.2 / 8.0 GB</strong></span>
          <span className="cyber-evasion-stat">TRACE EVASION: 99.4%</span>
        </div>
      </div>
    </div>
  );
}
