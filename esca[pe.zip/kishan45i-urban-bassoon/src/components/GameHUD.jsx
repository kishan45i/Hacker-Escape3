import React from 'react';
import './GameHUD.css';

export function GameHUD({ score, level, lives, timeRemaining }) {
  const seconds = Math.ceil(timeRemaining / 1000);
  const isLowTime = timeRemaining < 10000;

  return (
    <div className="game-hud">
      <div className={`hud-item timer ${isLowTime ? 'low-time' : ''}`}>
        <div className="hud-label">TIME</div>
        <div className="hud-value">{seconds}s</div>
      </div>

      <div className="hud-item score">
        <div className="hud-label">SCORE</div>
        <div className="hud-value">{score}</div>
      </div>

      <div className="hud-item level">
        <div className="hud-label">LEVEL</div>
        <div className="hud-value">{level}</div>
      </div>

      <div className="hud-item lives">
        <div className="hud-label">LIVES</div>
        <div className="hud-hearts">
          {[...Array(3)].map((_, i) => (
            <span key={i} className={`heart ${i < lives ? 'alive' : 'dead'}`}>
              ❤️
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
