import React, { useState, useEffect } from 'react';
import './App.css';
import { Intro } from './components/Intro';
import { StartScreen } from './components/StartScreen';
import { GameScreen } from './components/GameScreen';
import { GameOverScreen } from './components/GameOverScreen';
import { VictoryScreen } from './components/VictoryScreen';
import { HowToPlayScreen } from './components/HowToPlayScreen';
import { LeaderboardScreen } from './components/LeaderboardScreen';
import { CyberHeader } from './components/CyberHeader';
import { audioManager } from './lib/audio';
import { storage } from './lib/storage';

function App() {
  const [gameState, setGameState] = useState('start'); // start, intro, countdown, playing, gameOver, victory, howToPlay, leaderboard
  const [showIntro, setShowIntro] = useState(true);
  const [muted, setMuted] = useState(() => storage.isMuted());
  const [gameStats, setGameStats] = useState(null);

  useEffect(() => {
    audioManager.init();
    audioManager.setMuted(muted);
    storage.setMuted(muted);
  }, [muted]);

  const handleStartGame = () => {
    setShowIntro(true);
    setGameState('intro');
  };

  const handleIntroComplete = () => {
    setShowIntro(false);
    setGameState('playing');
  };

  const handleGameOver = (stats) => {
    setGameStats(stats);
    storage.incrementGamesPlayed();
    storage.addScore(stats.score, stats.level, stats.bestCombo);
    setGameState('gameOver');
  };

  const handleVictory = (stats) => {
    setGameStats(stats);
    storage.incrementGamesPlayed();
    storage.addScore(stats.score, stats.level, stats.bestCombo);
    setGameState('victory');
  };

  const handlePlayAgain = () => {
    setShowIntro(true);
    setGameState('intro');
  };

  const handleMainMenu = () => {
    setGameState('start');
  };

  const handleHowToPlay = () => {
    setGameState('howToPlay');
  };

  const handleLeaderboard = () => {
    setGameState('leaderboard');
  };

  const handleBack = () => {
    setGameState('start');
  };

  const toggleMute = () => {
    setMuted(!muted);
  };

  return (
    <div className="app">
      {/* Top Cyber Command Header & Ticker (Stitch Design System) */}
      <CyberHeader
        gameState={gameState}
        onNavigate={setGameState}
        onStartGame={handleStartGame}
        muted={muted}
        onToggleMute={toggleMute}
      />

      {/* Scanlines Effect */}
      <div className="scanlines"></div>

      {/* Grid Background */}
      <div className="grid-background"></div>

      {/* Main View Area */}
      <div className="app-main-viewport">
        {/* Game States */}
        {showIntro && gameState === 'intro' && (
          <Intro onIntroComplete={handleIntroComplete} />
        )}

        {gameState === 'start' && (
          <StartScreen
            onStartGame={handleStartGame}
            onHowToPlay={handleHowToPlay}
            onLeaderboard={handleLeaderboard}
          />
        )}

        {gameState === 'playing' && !showIntro && (
          <GameScreen
            onGameOver={handleGameOver}
            onVictory={handleVictory}
            muted={muted}
          />
        )}

        {gameState === 'gameOver' && (
          <GameOverScreen
            stats={gameStats}
            onPlayAgain={handlePlayAgain}
            onMainMenu={handleMainMenu}
          />
        )}

        {gameState === 'victory' && (
          <VictoryScreen
            stats={gameStats}
            onPlayAgain={handlePlayAgain}
            onMainMenu={handleMainMenu}
          />
        )}

        {gameState === 'howToPlay' && (
          <HowToPlayScreen onBack={handleBack} />
        )}

        {gameState === 'leaderboard' && (
          <LeaderboardScreen onBack={handleBack} />
        )}
      </div>
    </div>
  );
}

export default App;
